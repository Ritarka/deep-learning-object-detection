import smtplib, ssl

def send_email(message, subject=None):
    """_summary_

    Args:
        message (str): The message to send
        subject (str, optional): the subject line. Defaults to None.
    """
    if subject is None:
        subject = "Crimson Update" 
    if message is None:
        message = "This message is sent from Python."
    
    port = 465  # For SSL
    smtp_server = "smtp.gmail.com"
    sender_email = "ritarka.samanta@gmail.com"  # Enter your address
    receiver_email = "ritarka.samanta@gmail.com"  # Enter receiver address
    password = "wzhq ckib pcco ekjp"
    message = (
        f"Subject: {subject}\n"
        f"\n"
        f"{message}"
    )

    print(message)

    context = ssl.create_default_context()
    with smtplib.SMTP_SSL(smtp_server, port, context=context) as server:
        server.login(sender_email, password)
        server.sendmail(sender_email, receiver_email, message)
